#include <iostream>
#include <algorithm>
#include <iomanip>
#include <string.h>
#include <queue>
using namespace std;

struct process {
    int pid;
    int arrival_time;
    int burst_time;
    int start_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
    int response_time;
    int priority; // For Priority Scheduling
};

// Function Prototypes
void firstComeFirstServe(process p[], int n);
void shortestJobFirst(process p[], int n);
void roundRobin(process p[], int n, int tq);
void priorityScheduling(process p[], int n);
void nonpre_pri(process p[], int n);

// Comparison Functions
bool compareArrival(process p1, process p2) {
    return p1.arrival_time < p2.arrival_time;
}

bool compareID(process p1, process p2) {
    return p1.pid < p2.pid;
}

bool comparePriority(process p1, process p2) {
    return p1.priority > p2.priority;
}

bool compareArrivalThenBurst(process p1, process p2) {
    if (p1.arrival_time == p2.arrival_time) {
        return p1.burst_time < p2.burst_time;
    }
    return p1.arrival_time < p2.arrival_time;
}

// Main Function
int main() {
    int choice, n, tq;
    cout << "Enter the number of processes: ";
    cin >> n;

    struct process p[100];

    for (int i = 0; i < n; i++) {
        cout << "Enter arrival time of process " << i + 1 << ": ";
        cin >> p[i].arrival_time;
        cout << "Enter burst time of process " << i + 1 << ": ";
        cin >> p[i].burst_time;
        p[i].pid = i + 1;
        cout << endl;
    }

    cout << "Choose the scheduling algorithm:" << endl;
    cout << "1. First Come First Serve" << endl;
    cout << "2. Shortest Job First" << endl;
    cout << "3. Round Robin" << endl;
    cout << "4. Priority Scheduling" << endl;
    cout << "5. " << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
    case 1:
        firstComeFirstServe(p, n);
        break;
    case 2:
        shortestJobFirst(p, n);
        break;
    case 3:
        cout << "Enter time quantum for Round Robin: ";
        cin >> tq;
        roundRobin(p, n, tq);
        break;
    case 4:
        cout << "Enter priority of processes:" << endl;
        for (int i = 0; i < n; i++) {
            cout << "Enter priority of process " << i + 1 << ": ";
            cin >> p[i].priority;
        }
        priorityScheduling(p, n);
        break;
    case 5:
        nonpre_pri(p, n);
        break;
    default:
        cout << "Invalid choice!" << endl;
    }

    return 0;
}

// Function Definitions

void firstComeFirstServe(process p[], int n) {
    // Implementation of FCFS
     sort(p, p + n, compareArrival);
    float avg_turnaround_time;
    float avg_waiting_time;
    float avg_response_time;
    float cpu_utilisation;
    int total_turnaround_time = 0;
    int total_waiting_time = 0;
    int total_response_time = 0;
    int total_idle_time = 0;
    float throughput;

    p[0].start_time = p[0].arrival_time;
    p[0].completion_time = p[0].start_time + p[0].burst_time;
    p[0].turnaround_time = p[0].completion_time - p[0].arrival_time;
    p[0].waiting_time = p[0].turnaround_time - p[0].burst_time;
    p[0].response_time = p[0].start_time - p[0].arrival_time;

    total_turnaround_time += p[0].turnaround_time;
    total_waiting_time += p[0].waiting_time;
    total_response_time += p[0].response_time;
    total_idle_time += p[0].arrival_time;

    for (int i = 1; i < n; i++) {
        p[i].start_time = max(p[i - 1].completion_time, p[i].arrival_time);
        p[i].completion_time = p[i].start_time + p[i].burst_time;
        p[i].turnaround_time = p[i].completion_time - p[i].arrival_time;
        p[i].waiting_time = p[i].turnaround_time - p[i].burst_time;
        p[i].response_time = p[i].start_time - p[i].arrival_time;

        total_turnaround_time += p[i].turnaround_time;
        total_waiting_time += p[i].waiting_time;
        total_response_time += p[i].response_time;
        total_idle_time += (p[i].start_time - p[i - 1].completion_time);
    }

    avg_turnaround_time = (float)total_turnaround_time / n;
    avg_waiting_time = (float)total_waiting_time / n;
    avg_response_time = (float)total_response_time / n;
    cpu_utilisation = ((p[n - 1].completion_time - total_idle_time) / (float)p[n - 1].completion_time) * 100;
    throughput = float(n) / (p[n - 1].completion_time - p[0].arrival_time);

    sort(p, p + n, compareID);
    cout << endl;
    cout << "#P\tAT\tBT\tST\tCT\tTAT\tWT\tRT\t" << "\n" << endl;
    for (int i = 0; i < n; i++) {
        cout << p[i].pid << "\t" << p[i].arrival_time << "\t" << p[i].burst_time << "\t" << p[i].start_time << "\t" << p[i].completion_time << "\t" << p[i].turnaround_time << "\t" << p[i].waiting_time << "\t" << p[i].response_time << "\t" << "\n" << endl;
    }
    cout << "Average Turnaround Time = " << avg_turnaround_time << endl;
    cout << "Average Waiting Time = " << avg_waiting_time << endl;
    cout << "Average Response Time = " << avg_response_time << endl;
    cout << "CPU Utilization = " << cpu_utilisation << "%" << endl;
    cout << "Throughput = " << throughput << " process/unit time" << endl;
}

void shortestJobFirst(process p[], int n) {
    // Implementation of SJF
    sort(p, p + n, compareArrivalThenBurst);
    float avg_turnaround_time;
    float avg_waiting_time;
    float avg_response_time;
    float cpu_utilisation;
    int total_turnaround_time = 0;
    int total_waiting_time = 0;
    int total_response_time = 0;
    int total_idle_time = 0;
    float throughput;
    int is_completed[100] = {0};

    p[0].start_time = p[0].arrival_time;
    p[0].completion_time = p[0].arrival_time + p[0].burst_time;
    p[0].turnaround_time = p[0].completion_time - p[0].arrival_time;
    p[0].waiting_time = p[0].turnaround_time - p[0].burst_time;
    p[0].response_time = p[0].start_time - p[0].arrival_time;
    total_turnaround_time += p[0].turnaround_time;
    total_waiting_time += p[0].waiting_time;
    total_response_time += p[0].response_time;
    total_idle_time += p[0].arrival_time;
    int completed = 1;
    int current_time = p[0].completion_time;
    is_completed[0] = 1;

    while (completed != n) {
        int idx = -1;
        int mn = 10000000;
        for (int i = 1; i < n; i++) {
            if (p[i].arrival_time <= current_time && is_completed[i] == 0) {
                if (p[i].burst_time < mn) {
                    mn = p[i].burst_time;
                    idx = i;
                }
            }
        }
        if (idx == -1) {
            for (int i = 1; i < n; i++) {
                if (is_completed[i] == 0) {
                    idx = i;
                    break;
                }
            }
        }

        p[idx].start_time = max(current_time, p[idx].arrival_time);
        p[idx].completion_time = p[idx].start_time + p[idx].burst_time;
        p[idx].turnaround_time = p[idx].completion_time - p[idx].arrival_time;
        p[idx].waiting_time = p[idx].turnaround_time - p[idx].burst_time;
        p[idx].response_time = p[idx].start_time - p[idx].arrival_time;

        total_turnaround_time += p[idx].turnaround_time;
        total_waiting_time += p[idx].waiting_time;
        total_response_time += p[idx].response_time;
        total_idle_time += p[idx].start_time - current_time;

        is_completed[idx] = 1;
        completed++;
        current_time = p[idx].completion_time;
    }

    avg_turnaround_time = (float)total_turnaround_time / n;
    avg_waiting_time = (float)total_waiting_time / n;
    avg_response_time = (float)total_response_time / n;
    cpu_utilisation = ((current_time - total_idle_time) / (float)current_time) * 100;
    throughput = float(n) / (current_time - p[0].arrival_time);

    sort(p, p + n, compareID);
    cout << endl;
    cout << "#P\tAT\tBT\tST\tCT\tTAT\tWT\tRT\t" << "\n" << endl;
    for (int i = 0; i < n; i++) {
        cout << p[i].pid << "\t" << p[i].arrival_time << "\t" << p[i].burst_time << "\t" << p[i].start_time << "\t" << p[i].completion_time << "\t" << p[i].turnaround_time << "\t" << p[i].waiting_time << "\t" << p[i].response_time << "\t" << "\n" << endl;
    }
    cout << "Average Turnaround Time = " << avg_turnaround_time << endl;
    cout << "Average Waiting Time = " << avg_waiting_time << endl;
    cout << "Average Response Time = " << avg_response_time << endl;
    cout << "CPU Utilization = " << cpu_utilisation << "%" << endl;
    cout << "Throughput = " << throughput << " process/unit time" << endl;
}

void roundRobin(process p[], int n, int tq) {
    // Implementation of Round Robin
     sort(p, p + n, compareArrival);
    float avg_turnaround_time;
    float avg_waiting_time;
    float avg_response_time;
    float cpu_utilisation;
    int total_turnaround_time = 0;
    int total_waiting_time = 0;
    int total_response_time = 0;
    int total_idle_time = 0;
    float throughput;
    int burst_remaining[100];
    int idx = 0;
    for (int i = 0; i < n; i++) burst_remaining[i] = p[i].burst_time;
    int current_time = 0;
    queue<int> q;
    q.push(0);
    int completed = 0;
    int mark[100];
    memset(mark, 0, sizeof(mark));
    mark[0] = 1;
    while (completed != n) {
        idx = q.front();
        q.pop();
        if (burst_remaining[idx] == p[idx].burst_time) {
            p[idx].start_time = max(current_time, p[idx].arrival_time);
            total_idle_time += p[idx].start_time - current_time;
            current_time = p[idx].start_time;
        }
        if (burst_remaining[idx] - tq > 0) {
            burst_remaining[idx] -= tq;
            current_time += tq;
        }
        else {
            current_time += burst_remaining[idx];
            burst_remaining[idx] = 0;
            completed++;
            p[idx].completion_time = current_time;
            p[idx].turnaround_time = p[idx].completion_time - p[idx].arrival_time;
            p[idx].waiting_time = p[idx].turnaround_time - p[idx].burst_time;
            p[idx].response_time = p[idx].start_time - p[idx].arrival_time;

            total_turnaround_time += p[idx].turnaround_time;
            total_waiting_time += p[idx].waiting_time;
            total_response_time += p[idx].response_time;
        }
        for (int i = 1; i < n; i++) {
            if (burst_remaining[i] > 0 && p[i].arrival_time <= current_time && mark[i] == 0) {
                q.push(i);
                mark[i] = 1;
            }
        }
        if (burst_remaining[idx] > 0) q.push(idx);
        if (q.empty()) {
            for (int i = 1; i < n; i++) {
                if (burst_remaining[i] > 0) {
                    q.push(i);
                    mark[i] = 1;
                    break;
                }
            }
        }
    }

    avg_turnaround_time = (float)total_turnaround_time / n;
    avg_waiting_time = (float)total_waiting_time / n;
    avg_response_time = (float)total_response_time / n;
    cpu_utilisation = ((current_time - total_idle_time) / (float)current_time) * 100;
    throughput = float(n) / (current_time - p[0].arrival_time);

    sort(p, p + n, compareID);
    cout << endl;
    cout << "#P\tAT\tBT\tST\tCT\tTAT\tWT\tRT\t" << "\n" << endl;
    for (int i = 0; i < n; i++) {
        cout << p[i].pid << "\t" << p[i].arrival_time << "\t" << p[i].burst_time << "\t" << p[i].start_time << "\t" << p[i].completion_time << "\t" << p[i].turnaround_time << "\t" << p[i].waiting_time << "\t" << p[i].response_time << "\t" << "\n" << endl;
    }
    cout << "Average Turnaround Time = " << avg_turnaround_time << endl;
    cout << "Average Waiting Time = " << avg_waiting_time << endl;
    cout << "Average Response Time = " << avg_response_time << endl;
    cout << "CPU Utilization = " << cpu_utilisation << "%" << endl;
    cout << "Throughput = " << throughput << " process/unit time" << endl;
}

void priorityScheduling(process p[], int n) {
    sort(p, p + n, comparePriority);
    float avg_turnaround_time;
    float avg_waiting_time;
    float avg_response_time;
    float cpu_utilisation;
    int total_turnaround_time = 0;
    int total_waiting_time = 0;
    int total_response_time = 0;
    int total_idle_time = 0;
    float throughput;
    int is_completed[100] = {0};
    int current_time = 0;
    int completed = 0;
    while (completed != n) {
        int idx = -1;
        int max_priority = -1;
        for (int i = 0; i < n; i++) {
            if (p[i].arrival_time <= current_time && is_completed[i] == 0) {
                if (p[i].priority > max_priority) {
                    max_priority = p[i].priority;
                    idx = i;
                }
                if (p[i].priority == max_priority) {
                    if (p[i].arrival_time < p[idx].arrival_time) {
                        max_priority = p[i].priority;
                        idx = i;
                    }
                }
            }
        }
        if (idx != -1) {
            p[idx].start_time = current_time;
            p[idx].completion_time = p[idx].start_time + p[idx].burst_time;
            p[idx].turnaround_time = p[idx].completion_time - p[idx].arrival_time;
            p[idx].waiting_time = p[idx].turnaround_time - p[idx].burst_time;
            p[idx].response_time = p[idx].start_time - p[idx].arrival_time;

            total_turnaround_time += p[idx].turnaround_time;
            total_waiting_time += p[idx].waiting_time;
            total_response_time += p[idx].response_time;
            is_completed[idx] = 1;
            completed++;
            current_time = p[idx].completion_time;
        }
        else {
            current_time++;
        }
    }

    avg_turnaround_time = (float)total_turnaround_time / n;
    avg_waiting_time = (float)total_waiting_time / n;
    avg_response_time = (float)total_response_time / n;
    cpu_utilisation = ((current_time - total_idle_time) / (float)current_time) * 100;
    throughput = float(n) / (current_time - p[0].arrival_time);

    sort(p, p + n, compareID);
    cout << endl;
   
    for (int i = 0; i < n; i++) {
        cout << p[i].pid << "\t" << p[i].arrival_time << "\t" << p[i].burst_time << "\t" << p[i].start_time << "\t" << p[i].completion_time << "\t" << p[i].turnaround_time << "\t" << p[i].waiting_time << "\t" << p[i].response_time << "\t" << "\n" << endl;
    }
    cout << "Average Turnaround Time = " << avg_turnaround_time << endl;
    cout << "Average Waiting Time = " << avg_waiting_time << endl;
    cout << "Average Response Time = " << avg_response_time << endl;
    cout << "CPU Utilization = " << cpu_utilisation << "%" << endl;
    cout << "Throughput = " << throughput << " process/unit time" << endl;
}

    void nonpre_pri(process p[], int n) {
    // Implement Non-preemptive Priority Scheduling Algorithm here
    float avg_turnaround_time;
    float avg_waiting_time;
    float avg_response_time;
    float cpu_utilisation;
    int total_turnaround_time = 0;
    int total_waiting_time = 0;
    int total_response_time = 0;
    int total_idle_time = 0;
    float throughput;
    int is_completed[100];
    memset(is_completed, 0, sizeof(is_completed));
    cout << setprecision(2) << fixed;

    // Sort processes by arrival time
    sort(p, p + n, compareArrival);

    // Prompt user for priorities
    for (int i = 0; i < n; i++) {
        cout << "Enter priority of process " << i + 1 << ": ";
        cin >> p[i].priority;
    }

    // Initialize the first process
    p[0].start_time = p[0].arrival_time;
    p[0].completion_time = p[0].arrival_time + p[0].burst_time;
    p[0].turnaround_time = p[0].completion_time - p[0].arrival_time;
    p[0].waiting_time = p[0].turnaround_time - p[0].burst_time;
    p[0].response_time = p[0].start_time - p[0].arrival_time;
    total_turnaround_time += p[0].turnaround_time;
    total_waiting_time += p[0].waiting_time;
    total_response_time += p[0].response_time;
    total_idle_time += p[0].arrival_time;

    // Start processing remaining processes
    int completed = 1;
    int current_time = p[0].completion_time;
    is_completed[0] = 1;

    while (completed != n) {
        int idx = -1;
        int mx = -1;
        for (int i = 1; i < n; i++) {
            if (p[i].arrival_time <= current_time && is_completed[i] == 0) {
                if (p[i].priority > mx) {
                    mx = p[i].priority;
                    idx = i;
                }
            }
        }
        if (idx == -1) {
            for (int i = 1; i < n; i++) {
                if (is_completed[i] == 0) {
                    idx = i;
                    break;
                }
            }
        }
        p[idx].start_time = max(current_time, p[idx].arrival_time);
        p[idx].completion_time = p[idx].start_time + p[idx].burst_time;
        p[idx].turnaround_time = p[idx].completion_time - p[idx].arrival_time;
        p[idx].waiting_time = p[idx].turnaround_time - p[idx].burst_time;
        p[idx].response_time = p[idx].start_time - p[idx].arrival_time;

        total_turnaround_time += p[idx].turnaround_time;
        total_waiting_time += p[idx].waiting_time;
        total_response_time += p[idx].response_time;
        total_idle_time += current_time - p[idx].start_time;
        total_idle_time += (p[idx].start_time - current_time);

        is_completed[idx] = 1;
        completed++;
        current_time = p[idx].completion_time;
    }

    // Calculate metrics
    avg_turnaround_time = (float)total_turnaround_time / n;
    avg_waiting_time = (float)total_waiting_time / n;
    avg_response_time = (float)total_response_time / n;
    cpu_utilisation = ((p[n - 1].completion_time - total_idle_time) / (float)p[n - 1].completion_time) * 100;
    throughput = float(n) / (p[n - 1].completion_time - p[0].arrival_time);

    // Sort processes by PID before printing
    sort(p, p + n, compareID);

    // Print results
    cout << endl << endl;
    cout << "#P\t" << "AT\t" << "BT\t" << "PRI\t" << "ST\t" << "CT\t" << "TAT\t" << "WT\t" << "RT\t" << "\n" << endl;
    for (int i = 0; i < n; i++) {
        cout << p[i].pid << "\t" << p[i].arrival_time << "\t" << p[i].burst_time << "\t" << p[i].priority << "\t" << p[i].start_time << "\t" << p[i].completion_time << "\t" << p[i].turnaround_time << "\t" << p[i].waiting_time << "\t" << p[i].response_time << "\t" << "\n" << endl;
    }
    cout << "Throughput = " << avg_turnaround_time << endl;
    cout << "Average Waiting Time = " << avg_waiting_time << endl;
    cout << "Average Response Time = " << avg_response_time << endl;
    cout << "CPU Utilization = " << cpu_utilisation << "%" << endl;
    cout << "Average turnaround time = " << throughput << " process/unit time" << endl;
}
